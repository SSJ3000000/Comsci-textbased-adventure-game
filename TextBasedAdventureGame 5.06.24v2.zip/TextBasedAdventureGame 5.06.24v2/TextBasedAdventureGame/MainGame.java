import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList; 

public class MainGame {
    // Variables
    public int skeletons; // used for skeletons switch statement
    public int potions; // used for potions switch statement
    public int miniBossBattle; // used for miniBossBattle switch statement
    public ArrayList<String> inventory = new ArrayList<String>(); // ArrayList for inventory

    /**
     * Constructor for objects of class MainGame
     */
    public MainGame() {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Room 1: Where am I?");
        System.out.println("");
        System.out.println("");

        System.out.println("You wake up on a twin size bed with red silky bed sheets, you're tied to the bed with pink fuzzy handcuffs.");
        System.out.println("Luckily there are keys that unlock the hand cuffs on the pillow next to you that you use to unlock cuffs.");
        System.out.println("");
        System.out.println("You stand up and notice that you have nothing on you except a basic tee and trousers");
        System.out.println("You notice chains and what seem to be like bondage hanging from the ceiling.");
        System.out.println("You go up to the only door, when you touch the handle you sense that there's probably something you don't wanna see behind it.");
        System.out.println("");
        System.out.println("Press ENTER to continue.");
        
        if (keyboard.nextLine().equals("")) {
            room2();
        }
    }
    

    // Method for Room 2 scenario
    public void room2() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("Room 2: First Encounter");
        System.out.println("");
        System.out.println("You open the door and immediately a volley of arrows race past your head.");
        System.out.println("Three skeletons look at you with bloodlust");
        System.out.println("");
        System.out.println("What do you do?");
        System.out.println("");
        System.out.println("1. You charge at the closest skeleton and try to steal its bow.");
        System.out.println("2. You back to the other room and close the door");
        System.out.println("3. You run around the room in circles");

        String userInput = keyboard.nextLine();

        // Check if the user wants to check inventory
        if (userInput.equals("inventory")) {
            skeletons = 4; // Assigning 4 to skeletons if user input is "inventory"
        } else {
            skeletons = Integer.parseInt(userInput); // Parsing the user input to an integer
        }

        // Switch statement to handle user choice in Room 2
        switch (skeletons) {
            case 1:
                System.out.println("You were successfully able to steal one of the skeleton's bow, but you didn't grab any arrows so the other 2 skeletons shoot you and you die.");
                break;

            case 2:
                System.out.println("You go back to the previous room but the skeletons' arrows pierce through the door and you die.");
                break;

            case 3:
                System.out.println("You run around the room until the skeletons run out of arrows, so you charge at them and kill them all with your fists.");
                room3();
                break;

            case 4:
                checkInventory();
                room2();
                break;

            default:
                System.out.println("ERROR: Please input a valid option.");
                room2();
                break;
        }
    }

    // Method for Room 3 scenario
    public void room3() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("Room 3: Potion Shop");
        System.out.println("");
        System.out.println("After narrowly killing all 3 skeletons and avoiding death.");
        System.out.println("You go up to one of their dead remains and notice some gold was on the ground next to it.");
        System.out.println("You pick up 10 gold pieces and the skeleton's bow and arrow");
        
        // Adding the 10 gold pieces to inventory
        String goldPieces = "10 Gold Pieces";
        inventory.add(goldPieces);
        
        // Adding the bow and arrow to inventory
        String bowAndArrow = "Bow and Arrow";
        inventory.add(bowAndArrow);
        
        System.out.println("");
        System.out.println("");
        System.out.println("After looting the skeletons' corpses, you see another door to your left.");
        System.out.println("Before opening the door you carefully peek through it.");
        System.out.println("You see a room completely decorated with books, potions, and other magical items. You also see a stall that seems to sell potions with a shopkeeper at the front.");
        System.out.println("Curious, you go up to him and see what he sells.");
        System.out.println("");
        System.out.println("");
        System.out.println("Shopkeeper: HELLO, HOW MAY I HELP YOU TODAY?");
        System.out.println("Hi, I have 10 gold pieces, what can I buy with that?");
        System.out.println("Shopkeeper: UNFORTUNATELY, THAT WON'T GET YOU A LOT BUT THAT CAN GET YOU MOST OF OUR POTIONS.");
        System.out.println("What are they?");
        
        // List of potions available for purchase
        String[] potionList = new String[] {"1. Regeneration", "2. Strength", "3. Speed"};
        System.out.println("Shopkeeper: THAT COULD GET YOU:");
        System.out.println(Arrays.toString(potionList));
        System.out.println("");
        System.out.println("Which one would you like to buy?");

        String userInput = keyboard.nextLine();

        // Check if the user wants to check inventory
        if (userInput.equals("inventory")) {
            potions = 4; // Assigning 4 to potions if user input is "inventory"
        } else {
            potions = Integer.parseInt(userInput); // Parsing the user input to an integer
        }

        // Switch statement to handle user choice of potion
        switch (potions) {
            case 1:
                System.out.println("Shopkeeper: GOOD CHOICE, HERE YOU GO.");
                System.out.println("He hands you a potion of regeneration and you give him your 10 gold pieces.");
                inventory.remove(goldPieces); // Removing the 10 gold you just spent.
                String regenerationPotion = "Regeneration Potion";
                inventory.add(regenerationPotion);
                room4();
                break;

            case 2:
                System.out.println("Shopkeeper: GOOD CHOICE, HERE YOU GO.");
                System.out.println("He hands you a potion of strength and you give him your 10 gold pieces.");
                inventory.remove(goldPieces); // Removing the 10 gold you just spent.
                String strengthPotion = "Strength Potion";
                inventory.add(strengthPotion);
                room4();
                break;

            case 3:
                System.out.println("Shopkeeper: GOOD CHOICE, HERE YOU GO.");
                System.out.println("He hands you a potion of speed and you give him your 10 gold pieces.");
                inventory.remove(goldPieces); // Removing the 10 gold you just spent.
                String speedPotion = "Speed Potion";
                inventory.add(speedPotion);
                room4();
                break;

            case 4:
                checkInventory();
                room3();
                break;

            default:
                System.out.println("ERROR: Please input a valid option.");
                
                break;
        }
    }

    // Method for Room 4 scenario
    public void room4() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("Room 4: Baby");
        System.out.println("");
        System.out.println("When the potion comes in contact with your hand, the whole room, including the shopkeeper, starts to turn into dust.");
        System.out.println("All the books, the potions, the stall, everything starts to dust away.");
        System.out.println("The only thing that's still intact is the potion that he handed you.");
        System.out.println("");
        System.out.println("You notice a door that forms out of thin air in the corner of the room where the bookshelves used to be.");
        System.out.println("You walk up to the door and a piece of paper falls down to your feet.");
        System.out.println("");
        System.out.println("Press ENTER to pick up.");

        if (keyboard.nextLine().equals("")) {
            room4Part2();
        }
    }

    // Continuation of Room 4 scenario
    public void room4Part2() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.println("You bend over and pick up the piece paper, you turn it over and theres text that reads:");
        System.out.println();
        System.out.println("Beware of the monsterous beast, don't let its adorably cute face and apparence deceive you.");
        System.out.println("It has the strength and size of a hippopotamus. It cries echo through the whole dungeon, as loud as a flock of sheep.");
        System.out.println("Be prepared, for it will not let you pass without a fight. And remember it's not as friendly as a kiwi!");
        System.out.println("");
        System.out.println("PRESS ENTER to continue.");
        
        if (keyboard.nextLine().equals("")) {
            miniBossBattle();
        }
    }
    
    public void miniBossBattle() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("As soon as you finished reading the piece of paper");
        System.out.println("You feel a powerful presences behind you, you slowly turn your head around and see,");
        System.out.println("A massive hippo sized bald baby sucking on a pacifier just as big");
        System.out.println("");
        System.out.println("ME HUNGRY ME WANT FOOOOD!!!!!!!!");
        System.out.println("The babies ear deafening scream put you off balance, but before you know it the baby starts crawling at you suprisingly fast.");
        System.out.println("");
        System.out.println("");

       System.out.println("1. You quickly equip the bow from your inventory and spam all your arrows while circling the baby.");
        System.out.println("2. You calmly walk stand your ground try to converse with the baby and calm it down.");
        
        
        String userInput = keyboard.nextLine();

        
     // Check if the user wants to check inventory
     if (userInput.equals("inventory")) {
        miniBossBattle = 4; // Assigning 4 to miniBossBattle if user input is "inventory"
    } else {
        miniBossBattle = Integer.parseInt(userInput); // Parsing the user input to an integer
    }

    switch (miniBossBattle) {
        case 1:
            System.out.println("The barrage of arrows  ");
            break;

        case 2:
            System.out.println("The baby stops his attack but while trying to converse with it he gets a confused expression and just grabs you and eat you.");
            break;


        case 4:
            checkInventory();
            miniBossBattle();
            break;

        default:
            System.out.println("ERROR: Please input a valid option.");
            break;
    }

    }

    // Method to check inventory
    public void checkInventory() {                
        System.out.println("Here is your inventory: " + inventory); 
    }
    
    

    public static void main(String[] args) {
        new MainGame(); // Start the game
    }
}
