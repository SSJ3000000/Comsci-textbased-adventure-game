import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList; 

public class MainGame {
    // Variables
    public int skeletons; // used for skeletons switch statement
    public int potions; // used for potions switch statement
    public int miniBossBattle; // used for miniBossBattle switch statement
    public int miniBossBattlePhase2; // used for the second phase of the miniBossBattle
    public ArrayList<String> inventory = new ArrayList<String>(); // ArrayList for inventory

    /**
     * Constructor for objects of class MainGame
     */
    public MainGame() {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Room 1: Where am I?");
        System.out.println("");
        System.out.println("");

        System.out.println("You wake up on a twin size bed with red silky bed sheets, you're tied to the bed with pink fuzzy handcuffs.");
        System.out.println("Luckily there are keys that unlock the hand cuffs on the pillow next to you that you use to unlock cuffs.");
        System.out.println("");
        System.out.println("You stand up and notice that you have nothing on you except a basic tee and trousers");
        System.out.println("You notice chains and what seem to be like bondage hanging from the ceiling.");
        System.out.println("You go up to the only door, when you touch the handle you sense that there's probably something you don't wanna see behind it.");
        System.out.println("");
        System.out.println("Press ENTER to continue.");
        
        if (keyboard.nextLine().equals("")) {
            room2();
        }
    }
    

    // Method for Room 2 scenario
    public void room2() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("Room 2: First Encounter");
        System.out.println("");
        System.out.println("You open the door and immediately a volley of arrows race past your head.");
        System.out.println("Three skeletons look at you with bloodlust");
        System.out.println("");
        System.out.println("What do you do?");
        System.out.println("");
        System.out.println("1. You charge at the closest skeleton and try to steal its bow.");
        System.out.println("2. You back to the other room and close the door");
        System.out.println("3. You run around the room in circles");

        String userInput = keyboard.nextLine();

        // Check if the user wants to check inventory
        if (userInput.equals("inventory")) {
            skeletons = 4; // Assigning 4 to skeletons if user input is "inventory"
        } else {
            skeletons = Integer.parseInt(userInput); // Parsing the user input to an integer
        }

        // Switch statement to handle user choice in Room 2
        switch (skeletons) {
            case 1:
                System.out.println("You were successfully able to steal one of the skeleton's bow, but you didn't grab any arrows so the other 2 skeletons shoot you and you die.");
                break;

            case 2:
                System.out.println("You go back to the previous room but the skeletons' arrows pierce through the door and you die.");
                break;

            case 3:
                System.out.println("You run around the room until the skeletons run out of arrows, so you charge at them and kill them all with your fists.");
                room3();
                break;

            case 4:
                checkInventory();
                room2();
                break;

            default:
                System.out.println("ERROR: Please input a valid option.");
                room2();
                break;
        }
    }

    // Method for Room 3 scenario
    public void room3() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("Room 3: Potion Shop");
        System.out.println("");
        System.out.println("After narrowly killing all 3 skeletons and avoiding death.");
        System.out.println("You go up to one of their dead remains and notice some gold was on the ground next to it.");
        System.out.println("You pick up 10 gold pieces and the skeleton's bow and arrow");
        
        // Adding the 10 gold pieces to inventory
        String goldPieces = "10 Gold Pieces";
        inventory.add(goldPieces);
        
        // Adding the bow and arrow to inventory
        String bowAndArrow = "Bow and Arrow";
        inventory.add(bowAndArrow);
        
        System.out.println("");
        System.out.println("");
        System.out.println("After looting the skeletons' corpses, you see another door to your left.");
        System.out.println("Before opening the door you carefully peek through it.");
        System.out.println("You see a room completely decorated with books, potions, and other magical items. You also see a stall that seems to sell potions with a shopkeeper at the front.");
        System.out.println("Curious, you go up to him and see what he sells.");
        System.out.println("");
        System.out.println("");
        System.out.println("Shopkeeper: HELLO, HOW MAY I HELP YOU TODAY?");
        System.out.println("Hi, I have 10 gold pieces, what can I buy with that?");
        System.out.println("Shopkeeper: UNFORTUNATELY, THAT WON'T GET YOU A LOT BUT THAT CAN GET YOU MOST OF OUR POTIONS.");
        System.out.println("What are they?");
        
        // List of potions available for purchase
        String[] potionList = new String[] {"1. Regeneration", "2. Strength", "3. Speed"};
        System.out.println("Shopkeeper: THAT COULD GET YOU:");
        System.out.println(Arrays.toString(potionList));
        System.out.println("");
        System.out.println("Which one would you like to buy?");

        String userInput = keyboard.nextLine();

        // Check if the user wants to check inventory
        if (userInput.equals("inventory")) {
            potions = 4; // Assigning 4 to potions if user input is "inventory"
        } else {
            potions = Integer.parseInt(userInput); // Parsing the user input to an integer
        }

        // Switch statement to handle user choice of potion
        switch (potions) {
            case 1:
                System.out.println("Shopkeeper: GOOD CHOICE, HERE YOU GO.");
                System.out.println("He hands you a potion of regeneration and you give him your 10 gold pieces.");
                inventory.remove(goldPieces); // Removing the 10 gold you just spent.
                String regenerationPotion = "Regeneration Potion";
                inventory.add(regenerationPotion);
                room4();
                break;

            case 2:
                System.out.println("Shopkeeper: GOOD CHOICE, HERE YOU GO.");
                System.out.println("He hands you a potion of strength and you give him your 10 gold pieces.");
                inventory.remove(goldPieces); // Removing the 10 gold you just spent.
                String strengthPotion = "Strength Potion";
                inventory.add(strengthPotion);
                room4();
                break;

            case 3:
                System.out.println("Shopkeeper: GOOD CHOICE, HERE YOU GO.");
                System.out.println("He hands you a potion of speed and you give him your 10 gold pieces.");
                inventory.remove(goldPieces); // Removing the 10 gold you just spent.
                String speedPotion = "Speed Potion";
                inventory.add(speedPotion);
                room4();
                break;

            case 4:
                checkInventory();
                room3();
                break;

            default:
                System.out.println("ERROR: Please input a valid option.");
                
                break;
        }
    }

    // Method for Room 4 scenario
    public void room4() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("Room 4: Baby");
        System.out.println("");
        System.out.println("When the potion comes in contact with your hand, the whole room, including the shopkeeper, starts to turn into dust.");
        System.out.println("All the books, the potions, the stall, everything starts to dust away.");
        System.out.println("The only thing that's still intact is the potion that he handed you.");
        System.out.println("");
        System.out.println("You notice a door that forms out of thin air in the corner of the room where the bookshelves used to be.");
        System.out.println("You walk up to the door and a piece of paper falls down to your feet.");
        System.out.println("");
        System.out.println("Press ENTER to pick up.");

        if (keyboard.nextLine().equals("")) {
            room4Part2();
        }
    }

    // Continuation of Room 4 scenario
    public void room4Part2() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.println("You bend over and pick up the piece paper, you turn it over and theres text that reads:");
        System.out.println();
        System.out.println("Beware of the monsterous beast, don't let its adorably cute face and apparence deceive you.");
        System.out.println("It has the strength and size of a hippopotamus. It cries echo through the whole dungeon, as loud as a flock of sheep.");
        System.out.println("Be prepared, for it will not let you pass without a fight. And remember it's not as friendly as a kiwi!");
        System.out.println("");
        System.out.println("PRESS ENTER to continue.");
        
        if (keyboard.nextLine().equals("")) {
            miniBossBattle();
        }
    }
    
    public void miniBossBattle() {
        Scanner keyboard = new Scanner(System.in);
       // int miniBossBattlePhase2;
        System.out.println("");
        System.out.println("As soon as you finished reading the piece of paper");
        System.out.println("You feel a powerful presences behind you, you slowly turn your head around and see,");
        System.out.println("A massive hippo sized bald baby sucking on a pacifier just as big");
        System.out.println("");
        System.out.println("ME HUNGRY ME WANT FOOOOD!!!!!!!!");
        System.out.println("The babies ear deafening scream put you off balance, but before you know it the baby starts crawling at you suprisingly fast.");
        System.out.println("");
        System.out.println("");

       System.out.println("1. You quickly equip the bow from your inventory and spam all your arrows while circling the baby.");
        System.out.println("2. You calmly walk stand your ground try to converse with the baby and calm it down.");
        
        
        String userInput = keyboard.nextLine();

        
     // Check if the user wants to check inventory
     if (userInput.equals("inventory")) {
        miniBossBattle = 4; // Assigning 4 to miniBossBattle if user input is "inventory"
    } else {
        miniBossBattle = Integer.parseInt(userInput); // Parsing the user input to an integer
    }

    switch (miniBossBattle) {
        case 1:
            String bowAndArrow = "Bow and Arrow";
            inventory.remove(bowAndArrow);
            System.out.println("");
            System.out.println(""); 
            System.out.println("One of the arrows you sprayed at the baby hits his eyes which brings him down to the ground.");
            System.out.println("But he doesn't seem to be died just yet, the baby gets back up looking even more angry than before");
            System.out.println("It starts crawling towards you demonically.");
            System.out.println(""); 
            miniBossBattlePhase2();
            break;

        case 2:
            System.out.println(""); 
            System.out.println("The baby stops his attack but while trying to converse with it he gains a confused expression and just grabs you and eats you.");
            break;


        case 4:
            checkInventory();
            miniBossBattle();
            break;

        default:
            System.out.println("ERROR: Please input a valid option.");
            break;
    }


        
    
    }
    
    public void miniBossBattlePhase2() {
        Scanner keyboard = new Scanner(System.in);

        String potionType = "";
    if (inventory.contains("Regeneration Potion")) {
        potionType = "Regeneration";
    } else if (inventory.contains("Strength Potion")) {
        potionType = "Strength";
    } else if (inventory.contains("Speed Potion")) {
        potionType = "Speed";
    }
   
        System.out.println(""); 
        System.out.println("As the demon baby is crawling towards you start to panick"); 
        System.out.println("You used the last of your arrows just now so you don't have anything to defend yourself with "); 
        System.out.println("But in that moment you realise you still have your potion that you brought before");
        System.out.println("You pull your potion of " + potionType + " and drink it" );
        System.out.println(""); 
        System.out.println("Press ENTER to continue."); 
        if (keyboard.nextLine().equals("")) {
            potionScenarios();
        }
               
    }
    
    
public void potionOneScenario() {
    Scanner keyboard = new Scanner(System.in);

      String potionType = "";
    if (inventory.contains("Regeneration Potion")) {
        potionType = "Regeneration";
    } else if (inventory.contains("Strength Potion")) {
        potionType = "Strength";
    } else if (inventory.contains("Speed Potion")) {
        potionType = "Speed";
    }
    
    System.out.println("");
    System.out.println(""); 
    System.out.println(""); 
    System.out.println("After drinking your potion of " + potionType +" you feel as if you just got pure caffine injected into your blood stream");
    System.out.println("However unfortunatly, the potion doesn't really do anything besides make you feel energised and heal any cuts or bruises.");
    System.out.println("And while you were busy getting your potion out and drinking it the baby was still charging towards you, and unfortunatly killed you.");
    System.out.println("");
    System.out.println("Maybe you should of chosen another potion :(");
    
    

}

public void potionTwoScenario() {
    Scanner keyboard = new Scanner(System.in);
    
     String potionType = "";
    if (inventory.contains("Regeneration Potion")) {
        potionType = "Regeneration";
    } else if (inventory.contains("Strength Potion")) {
        potionType = "Strength";
    } else if (inventory.contains("Speed Potion")) {
        potionType = "Speed";
    }
    
    String squencePaper = "Squence Paper";
    inventory.add(squencePaper);
    String babyFigure = "Baby Figure";
    inventory.add(babyFigure);
    
    System.out.println("");
    System.out.println(""); 
    System.out.println(""); 
    System.out.println("After drinking your potion of " + potionType +" you feel your muscles literally growing");
    System.out.println("They feel as if they're about to burst of your skin, but in a good way");
    System.out.println("With your new found power you charge right towards the baby who is also still charging towards you");
    System.out.println("Your fists clash with nose of the baby literally ripping the head clean off");
    System.out.println("");
    System.out.println("You celebrate your victory, but the effects of the potion fades after you killed the baby.");
    System.out.println("You inspect the babys body hopeing thast their might be something useful for later");
    System.out.println("You find another piece of paper but this time it it appears to be a squence of some source, it reads:");
    System.out.println("'Forward, Back, Left, Forward, Right'");
    System.out.println("You put it in your pockets because it'll come in useful later.");
    System.out.println("");
    System.out.println("After a while of searching the corpse of the dead baby you manage to find one final thing");
    System.out.println("A figurine of what seems like the baby you had just slain");
    System.out.println("Doesn't really seem to important but you stash it anyways just in case");
    System.out.println("");
    
    System.out.println("Press ENTER to continue."); 
    
    if (keyboard.nextLine().equals("")) {
            room5();
    }
    
}

public void potionThreeScenario(){
    Scanner keyboard = new Scanner(System.in);
    
     String potionType = "";
    if (inventory.contains("Regeneration Potion")) {
        potionType = "Regeneration";
    } else if (inventory.contains("Strength Potion")) {
        potionType = "Strength";
    } else if (inventory.contains("Speed Potion")) {
        potionType = "Speed";
    }
    
    String squencePaper = "Squence Paper";
    inventory.add(squencePaper);
    String babyFigure = "Baby Figure";
    inventory.add(babyFigure);
    
    System.out.println("");
    System.out.println(""); 
    System.out.println(""); 
    System.out.println("After drinking your potion of " + potionType +" you feel your legs literally growing");
    System.out.println("They feel as if they're about to burst of your skin, but in a good way");
    System.out.println("With your new found power you charge right towards the baby who is also still charging towards you");
    System.out.println("You do a round house kick that hits the baby directly on its nose, literally tearing the head clean off.");
    System.out.println("");
    System.out.println("You celebrate your victory, but the effects of the potion fades after you killed the baby.");
    System.out.println("You inspect the babys body hopeing thast their might be something useful for later");
    System.out.println("You find another piece of paper but this time it it appears to be a squence of some source, it reads:");
    System.out.println("'Forward, Back, Left, Forward, Right'");
    System.out.println("You put it in your pockets because it'll come in useful later.");
    System.out.println("");
    System.out.println("After a while of searching the corpse of the dead baby you manage to find one final thing");
    System.out.println("A figurine of what seems like the baby you had just slain");
    System.out.println("Doesn't really seem to important but you stash it anyways just in case");
    System.out.println("");
    
    System.out.println("Press ENTER to continue."); 
    
    if (keyboard.nextLine().equals("")) {
            room5();
    }
}

public void room5() {
    String babyFigure = "Baby Figure";
    Scanner keyboard = new Scanner(System.in);
    System.out.println("");
    System.out.println("");
    System.out.println("");
    System.out.println("Room 5: Party");
    
    System.out.println(""); 
    System.out.println("When opening the door to the next room, you immediately notice that this room has a totally differnt vibe "); 
    System.out.println("This room was was more similar to the inside of a club rather than the dungeon you've been traversing"); 
    System.out.println("There were bright lights, a disco ball hanging the ceiling, a large dance floor in the middle, and a out of place pedestal looking thing in the the corner");
    System.out.println("You walk over over to the pedestal and there was a dent in on the pedstal, it looks like something need to place on it ");
    System.out.println("Conveniently you have a a baby figurine that looks perfect for it");
    System.out.println(""); 
    System.out.println("Press ENTER to place the figurine"); 
    inventory.remove(babyFigure);
    
    if (keyboard.nextLine().equals("")) {
            room5Phase2();
    }
}   

public void room5Phase2() {
    Scanner keyboard = new Scanner(System.in);
    System.out.println(""); 
    System.out.println(""); 
    System.out.println("When placing the figurine the dance floor in the middle of room lights up, flashing rainbow lights"); 
    System.out.println("A loud voice comes out of the speakers"); 
    System.out.println(""); 
    
    System.out.println("'TO LEAVE THIS ROOM ONE MUST COMPLETE THE FOLLOWING CHALLENGE.'"); 
    System.out.println("'STARTING FROM THE MIDDLE YOU MUST WALK A SPECIFIC SEQUENCE TOUCHING 5 SQUARES ON THE DANCE FLOOR'"); 
    System.out.println("'IF ONE FAILS THEY WILL BE IMMEDIATELY BE TERMINATED'"); 
    System.out.println(""); 
    System.out.println(""); 
    System.out.println("Hearing this to walk over to the middle of the dance floor");
    System.out.println("'YOUR CHALLENGE BEGINS NOW!'"); 
    System.out.println(""); 
    System.out.println("Press enter your the sequence."); 
    
    // converts users input to lowercase, removes spaces and commas, compares the cleaned up string to the target string.
    if (keyboard.nextLine().toLowerCase().replaceAll("[ ,]", "").equals("forwardbackleftforwardright")) {
        System.out.println("CONGRATULATIONS ON COMPLETEING THE CHALLENGE YOU MAY NOW ADVANCE.");
    room6();
} else {
System.out.println("Wrong sequence, you will now be terminated.");

    }  
    
}

public void room6() {
    System.out.println("");
    System.out.println("");
    System.out.println("");
    System.out.println("Room 6: GUNS"); 
    
    
}



// Method to check inventory
public void checkInventory() {                
    System.out.println("Here is your inventory: " + inventory); 
}
    
    // Method to check what potion in inventory in order to decide which sceanario to place player in.
    public void potionScenarios() {
        String potionType = "";
    if (inventory.contains("Regeneration Potion")) {
        potionType = "Regeneration";
    } else if (inventory.contains("Strength Potion")) {
        potionType = "Strength";
    } else if (inventory.contains("Speed Potion")) {
        potionType = "Speed";
    }
        
        
         if (potionType == "Regeneration") {
            potionOneScenario();
        } else if (potionType == "Strength") {
            potionTwoScenario();
        } else if (potionType == "Speed") {
            potionThreeScenario();
        }
    }
    
    
    // Method that starts the game
    public static void main(String[] args) {
        new MainGame(); // Start the game
    }
}
